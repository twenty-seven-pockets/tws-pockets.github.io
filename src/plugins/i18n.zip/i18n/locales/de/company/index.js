
import pages from './pages'

export default {
  name : "Kussy",
  slogans : {
    wholeBody : "Natural whole Body Experience",
    together : "Gemeinsame Erlebnisse",
    kissLips : "Ein Kuss der die Lippen erlebt",
  },disclaimer : {
    title : "Sensible Inhalte!",
    text : "Diese Webseite enthält Inhalte!"
  },
  words : {
    additional : "Gebrauchshinweise"
  },
  pages,
  
}