export default {
  
  "/impressum/impressum" : {
    title : "Impressum",
    nameAndAddresse : "Name und Anschrift",
    contactInformation : "Kontaktdaten",
    
  }
}