export default {
  
  //
  // news
  //
  "/news/news": {
    title: "Aktuelles und Neues",
    placeholder:
      "Durchsuchen Sie hier Aktuelles und Neuigkeiten rund um unsere Produkte.",
    noData: "Leider haben wir aktuell keine Neuigkeiten für Sie.",
    list: [
            {
            title : "Website Eröffnung",
            text : `Do sint nisi velit consectetur incididunt id voluptate. Aute laborum incididunt elit esse aute deserunt do dolore voluptate sit minim consequat irure esse. Occaecat cupidatat in fugiat aliquip dolor veniam ex est nostrud dolore Lorem. Dolor tempor in commodo eu officia fugiat ad dolor enim ipsum id qui ex aliquip.
      Magna velit elit sint sint occaecat dolor deserunt fugiat. Adipisicing excepteur in labore sint in sunt tempor ea labore. Dolor ea nisi cupidatat laboris tempor laboris ex commodo eu sunt dolore laborum magna est. Enim ullamco anim laboris cupidatat eu nulla ullamco proident aute deserunt pariatur cupidatat id. Exercitation ad sunt ad nulla. Fugiat consequat duis nostrud ex quis ad aliqua ullamco culpa nostrud velit.
      Consequat irure deserunt nisi elit in cillum incididunt sint laborum ut. Aliquip Lorem tempor enim labore reprehenderit mollit commodo deserunt deserunt tempor. Ut id in veniam aliqua incididunt aliquip adipisicing exercitation nostrud esse quis pariatur incididunt.
      Nulla occaecat eiusmod sunt anim deserunt. Esse id laborum ea sint Lorem labore aliqua exercitation laborum magna. Eiusmod qui laboris eiusmod in et pariatur quis laborum sunt consectetur commodo elit. Nulla dolor pariatur excepteur cillum sint non ea anim qui ullamco qui. Ipsum proident deserunt minim ullamco culpa ea nostrud elit.`
          }
    ],
  },
}