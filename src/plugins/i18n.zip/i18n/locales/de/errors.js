export default {
  title : "{error} - Fehler",
  goBack : "Zurück zur Homepage",
  404 : "Der von Ihnen gewählte Pfad '{route}' existiert leider nicht.",
  underConstruction : "Der von Ihnen gewählte Pfad '{route}' befindet sich noch im Aufbau."

}