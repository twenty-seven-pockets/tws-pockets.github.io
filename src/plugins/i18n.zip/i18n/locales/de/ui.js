export default {
  menu : {
    items : {
      aboutUs: { title: "Über uns", tooltip: "" },
      conservation: { title: "Nachhaltigkeit", tooltip: "" },
      news: { title: "Ankündigungen", tooltip: "" },
      further : { title: "Nützliches", tooltip: "" }, 
      tests: { title: "Zertifikation", tooltip: "" },
      product: { title: "Produkt", tooltip: "" },
      future: { title: "In der Zukunft", tooltip: "" },
      about: { title: "Impressum", tooltip: "" },
      help: { title: "Impressum", tooltip: "" },
      faq: { title: "Hilfe", tooltip: "Häufige Fragen" },
    }
  }
}