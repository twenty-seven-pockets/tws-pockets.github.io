export default {
  leave : "Verlassen",
  "ok" : "ok"
}