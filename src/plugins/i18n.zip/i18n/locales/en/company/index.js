
import pages from './pages'

export default {
  name : "Kussy",
  slogans : {
    wholeBody : "Natural whole Body Experience",
    together : "Gemeinsame Erlebnisse",
    kissLips : "Ein Kuss der die Lippen erlebt",
  },disclaimer : {
    title : "Sensitive Content",
    text : "This page contains adult content. Are you sure you want to continue?"
  },
  words : {
    additional : "Nützliches"
  },
  pages,
  
}